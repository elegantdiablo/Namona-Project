﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace NamonaDataBase.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NamonaController : ControllerBase
    {
    }
}