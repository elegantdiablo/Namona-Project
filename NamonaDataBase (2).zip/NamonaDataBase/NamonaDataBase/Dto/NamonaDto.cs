﻿namespace NamonaDataBase.Dto
{
    public class NamonaDto
    {
       
    }
}
